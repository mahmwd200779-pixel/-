package com.example.voicecontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** The "hands": performs taps, swipes, typing and global actions on any app. */
class PhoneControlService : AccessibilityService() {

    companion object {
        @Volatile var instance: PhoneControlService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---- global actions ----
    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun quickSettings() = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
    fun powerMenu() = performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
    fun lockScreen() = Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
    fun screenshot() = Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)

    // ---- gestures ----
    private fun gesture(path: Path, duration: Long) {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()
        dispatchGesture(g, null, null)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long = 300) {
        gesture(Path().apply { moveTo(x1, y1); lineTo(x2, y2) }, duration)
    }

    fun tap(x: Float, y: Float) {
        gesture(Path().apply { moveTo(x, y); lineTo(x + 1, y + 1) }, 60)
    }

    private fun screen() = resources.displayMetrics

    /** down=true shows content further down the page (finger swipes up). */
    fun scroll(down: Boolean) {
        val w = screen().widthPixels.toFloat(); val h = screen().heightPixels.toFloat()
        if (down) swipe(w / 2, h * 0.72f, w / 2, h * 0.28f) else swipe(w / 2, h * 0.28f, w / 2, h * 0.72f)
    }

    fun swipeSide(toLeft: Boolean) {
        val w = screen().widthPixels.toFloat(); val h = screen().heightPixels.toFloat()
        if (toLeft) swipe(w * 0.8f, h / 2, w * 0.2f, h / 2) else swipe(w * 0.2f, h / 2, w * 0.8f, h / 2)
    }

    // ---- text based interaction ----
    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val key = Normalizer.norm(text)
        // exact search first, then fuzzy search over every node
        var nodes: List<AccessibilityNodeInfo> = root.findAccessibilityNodeInfosByText(text)
        if (nodes.isEmpty()) nodes = collect(root).filter { n ->
            val t = Normalizer.norm((n.text ?: n.contentDescription ?: "").toString())
            t.isNotEmpty() && (t.contains(key) || key.contains(t))
        }
        for (n in nodes) {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        // fallback: tap the centre of the first match
        nodes.firstOrNull()?.let {
            val r = android.graphics.Rect(); it.getBoundsInScreen(r)
            if (!r.isEmpty) { tap(r.exactCenterX(), r.exactCenterY()); return true }
        }
        return false
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: collect(root).firstOrNull { it.isEditable } ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun clearText(): Boolean = typeText("")

    // ---- screen reading ----
    private fun collect(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            out.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return out
    }

    /** Compact text description of the current screen (used by the AI agent and "read screen"). */
    fun screenSummary(limit: Int = 80): String {
        val root = rootInActiveWindow ?: return "(no screen available)"
        val sb = StringBuilder("app: ${root.packageName}\n")
        var count = 0
        for (n in collect(root)) {
            if (!n.isVisibleToUser) continue
            val t = (n.text ?: n.contentDescription)?.toString()?.trim().orEmpty()
            val kind = when {
                n.isEditable -> "[input]"
                n.isClickable || n.isCheckable -> "[button]"
                n.isScrollable -> "[scrollable]"
                else -> if (t.isNotEmpty()) "[text]" else ""
            }
            if (kind.isEmpty() || (t.isEmpty() && kind != "[input]" && kind != "[scrollable]")) continue
            sb.append(kind).append(' ').append(t.take(80)).append('\n')
            if (++count >= limit) break
        }
        return sb.toString()
    }

    fun readableText(): String {
        val root = rootInActiveWindow ?: return ""
        return collect(root).filter { it.isVisibleToUser }
            .mapNotNull { (it.text ?: "").toString().takeIf { s -> s.isNotBlank() } }
            .joinToString(". ").take(600)
    }
}
