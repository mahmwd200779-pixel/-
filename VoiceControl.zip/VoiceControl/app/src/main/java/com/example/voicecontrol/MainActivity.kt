package com.example.voicecontrol

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private lateinit var wake: EditText
    private lateinit var key: EditText
    private lateinit var needWake: Switch
    private lateinit var english: Switch
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }

        fun button(text: String, onClick: () -> Unit) = Button(this).apply {
            this.text = text; setOnClickListener { onClick() }
            root.addView(this, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        status = TextView(this).apply { textSize = 16f }
        root.addView(status)

        button("1) منح الصلاحيات (ميكروفون، اتصال، جهات الاتصال)") { askPermissions() }
        button("2) تفعيل خدمة إمكانية الوصول") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        button("3) السماح بالظهور فوق التطبيقات") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("4) تعطيل تحسين البطارية للتطبيق") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }

        wake = EditText(this).apply { hint = "كلمة التنبيه"; setText(Prefs.wakeWord(this@MainActivity)) }
        needWake = Switch(this).apply { text = "اشترط كلمة التنبيه"; isChecked = Prefs.requireWake(this@MainActivity) }
        english = Switch(this).apply { text = "English"; isChecked = Prefs.lang(this@MainActivity).startsWith("en") }
        key = EditText(this).apply {
            hint = "مفتاح Claude API (اختياري)"; setText(Prefs.apiKey(this@MainActivity))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        listOf(wake, needWake, english, key).forEach { root.addView(it) }

        button("ابدأ الاستماع") {
            Prefs.save(this, key.text.toString(), wake.text.toString(), needWake.isChecked,
                if (english.isChecked) "en-US" else "ar-SA")
            VoiceService.stop(this)
            VoiceService.start(this)
            refresh()
        }
        button("أوقف الاستماع") { VoiceService.stop(this); refresh() }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        status.text = "الاستماع: " + (if (VoiceService.running) "يعمل" else "متوقف") +
            "\nخدمة إمكانية الوصول: " + (if (PhoneControlService.instance != null) "مفعّلة" else "غير مفعّلة")
    }

    private fun askPermissions() {
        val p = mutableListOf(
            Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(p.toTypedArray(), 1)
    }
}
