package com.example.voicecontrol

import android.content.Context
import android.media.AudioManager
import android.view.KeyEvent

/** Turns a spoken sentence into an action. Local rules first, AI agent as fallback. */
object CommandRouter {

    private fun rx(p: String) = Regex(p, RegexOption.IGNORE_CASE)

    fun handle(ctx: Context, raw: String, speak: (String) -> Unit) {
        val t = Normalizer.norm(raw)
        val svc = PhoneControlService.instance

        fun need(block: (PhoneControlService) -> Unit) {
            if (svc == null) speak("فعّل خدمة إمكانية الوصول أولاً") else block(svc)
        }
        fun ok(b: Boolean, done: String = "تم", fail: String = "لم أستطع") = speak(if (b) done else fail)
        fun any(vararg k: String) = k.any { t == Normalizer.norm(it) }
        fun starts(vararg k: String) = k.any { t.startsWith(Normalizer.norm(it)) }

        when {
            // ---- control of the listener itself ----
            any("توقف عن الاستماع", "وقف الاستماع", "stop listening") -> {
                speak("حسناً، أوقفت الاستماع"); VoiceService.stop(ctx)
            }

            // ---- navigation ----
            any("ارجع", "رجوع", "للخلف", "back", "go back") -> need { ok(it.back()) }
            any("الرئيسيه", "الشاشه الرئيسيه", "روح للرئيسيه", "home", "go home") -> need { ok(it.home()) }
            any("التطبيقات الاخيره", "التطبيقات المفتوحه", "recent apps", "recents") -> need { ok(it.recents()) }
            any("الاشعارات", "افتح الاشعارات", "notifications") -> need { ok(it.notifications()) }
            any("الاعدادات السريعه", "quick settings") -> need { ok(it.quickSettings()) }
            any("لقطه شاشه", "صور الشاشه", "خذ لقطه", "screenshot") -> need { ok(it.screenshot()) }
            any("اقفل الشاشه", "قفل الشاشه", "lock screen", "lock the phone") -> need { ok(it.lockScreen()) }
            any("قائمه الطاقه", "اطفاء الهاتف", "power menu") -> need { ok(it.powerMenu()) }
            any("شغل الشاشه", "صحي الشاشه", "wake screen") -> { Actions.wakeScreen(ctx); speak("تم") }

            // ---- scrolling / swiping ----
            starts("انزل", "مرر لتحت", "مرر للاسفل", "scroll down", "لتحت") -> need { it.scroll(true); speak("تم") }
            starts("اطلع", "مرر لفوق", "مرر للاعلى", "scroll up", "لفوق") -> need { it.scroll(false); speak("تم") }
            starts("اسحب يمين", "swipe right") -> need { it.swipeSide(false); speak("تم") }
            starts("اسحب يسار", "swipe left") -> need { it.swipeSide(true); speak("تم") }

            // ---- reading ----
            any("اقرا الشاشه", "اقرأ الشاشة", "read screen", "what's on screen") -> need {
                val s = it.readableText(); speak(if (s.isBlank()) "لا يوجد نص ظاهر" else s)
            }

            // ---- hardware ----
            rx("^(?:شغل|افتح|اضيء|اضئ|turn on)\\s+(?:الكشاف|الفلاش|المصباح|flashlight|torch)").containsMatchIn(t) ->
                ok(Actions.torch(ctx, true))
            rx("^(?:اطفي|اطفئ|سكر|اغلق|turn off)\\s+(?:الكشاف|الفلاش|المصباح|flashlight|torch)").containsMatchIn(t) ->
                ok(Actions.torch(ctx, false))
            starts("ارفع الصوت", "زود الصوت", "volume up", "louder") -> { Actions.volume(ctx, AudioManager.ADJUST_RAISE); speak("تم") }
            starts("اخفض الصوت", "وطي الصوت", "نقص الصوت", "volume down", "quieter") -> { Actions.volume(ctx, AudioManager.ADJUST_LOWER); speak("تم") }
            starts("كتم الصوت", "mute") -> { Actions.volume(ctx, AudioManager.ADJUST_MUTE); speak("تم") }
            any("وقف الموسيقى", "ايقاف مؤقت", "pause", "pause music") -> { Actions.mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE); speak("تم") }
            any("شغل الموسيقى", "كمل الموسيقى", "play", "play music", "resume") -> { Actions.mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PLAY); speak("تم") }
            any("التالي", "الاغنيه التاليه", "next", "next song") -> { Actions.mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_NEXT); speak("تم") }
            any("السابق", "الاغنيه السابقه", "previous", "previous song") -> { Actions.mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS); speak("تم") }

            else -> handleWithArgs(ctx, raw, t, svc, speak)
        }
    }

    private fun handleWithArgs(
        ctx: Context, raw: String, t: String, svc: PhoneControlService?, speak: (String) -> Unit
    ) {
        fun ok(b: Boolean, done: String = "تم", fail: String = "لم أستطع") = speak(if (b) done else fail)

        // type text (uses raw text so spelling is preserved)
        rx("^\\s*(?:اكتب|type|write)\\s+(.+)").find(raw)?.let { m ->
            if (svc == null) return speak("فعّل خدمة إمكانية الوصول أولاً")
            return ok(svc.typeText(m.groupValues[1].trim()), "كتبت", "لا يوجد حقل نص")
        }
        if (rx("^(?:امسح النص|امسح الكتابه|clear text)$").containsMatchIn(t)) {
            return ok(svc?.clearText() == true)
        }
        rx("^(?:اضغط(?: على)?|انقر(?: على)?|اختار|click(?: on)?|tap(?: on)?|press)\\s+(.+)").find(t)?.let { m ->
            if (svc == null) return speak("فعّل خدمة إمكانية الوصول أولاً")
            return ok(svc.clickText(m.groupValues[1]), "تم", "لم أجد ${m.groupValues[1]}")
        }
        rx("^(?:ابحث عن|search for|search|google)\\s+(.+)").find(t)?.let { m ->
            return ok(Actions.webSearch(ctx, m.groupValues[1]))
        }
        rx("^(?:اتصل ب|اتصل بـ|كلم|call|phone)\\s+(.+)").find(t)?.let { m ->
            return ok(Actions.call(ctx, m.groupValues[1]), "أتصل الآن", "لم أجد الرقم")
        }
        rx("(\\d+)\\s*(?:دقيقه|دقايق|دقائق|دقيقة|minutes?|mins?)").find(t)?.let { m ->
            if (t.contains("مؤقت") || t.contains("timer") || t.contains("منبه"))
                return ok(Actions.setTimer(ctx, m.groupValues[1].toInt()), "ضبطت المؤقت")
        }
        rx("^(?:افتح|شغل تطبيق|شغل|open|launch|start)\\s+(.+)").find(t)?.let { m ->
            if (Actions.openApp(ctx, m.groupValues[1])) return speak("أفتح ${m.groupValues[1]}")
            // not an installed app label → let the AI figure it out if available
        }

        // fallback: AI agent
        if (Prefs.apiKey(ctx).isNotBlank() && svc != null) {
            speak("حاضر")
            AgentClient.run(ctx, raw, speak)
        } else {
            speak("لم أفهم الأمر")
        }
    }
}
