package com.example.voicecontrol

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * AI fallback: reads the screen, asks Claude what to do next, executes the actions, repeats.
 * Only runs when the user entered an API key and the command wasn't handled by a local rule.
 */
object AgentClient {

    private const val SYSTEM = """You control an Android phone for a user who cannot touch the screen.
You get the user's command, the actions already done, and a text dump of the current screen.
Reply with ONLY a JSON object, no markdown:
{"done": true|false, "say": "short reply in the user's language", "actions": [ ... ]}
Action types:
 {"type":"click","text":"visible label"}
 {"type":"type","text":"text to type into the focused/first input"}
 {"type":"scroll","dir":"down"|"up"}
 {"type":"swipe","dir":"left"|"right"}
 {"type":"back"} {"type":"home"} {"type":"recents"} {"type":"notifications"}
 {"type":"open_app","name":"app name"}
 {"type":"search","query":"web search"}
 {"type":"wait"}
Set done=true when the task is complete or impossible. Use at most 3 actions per step.
Never confirm purchases, payments, deletions or sending money; instead set done=true and say you need the user to confirm by voice."""

    private val main = Handler(Looper.getMainLooper())

    fun run(ctx: Context, command: String, speak: (String) -> Unit) {
        Thread {
            val svc = PhoneControlService.instance ?: return@Thread
            val log = StringBuilder()
            var lastSay = ""
            for (step in 1..6) {
                val prompt = "Command: $command\nActions so far:\n$log\nCurrent screen:\n${svc.screenSummary()}"
                val reply = try { ask(ctx, prompt) } catch (e: Exception) {
                    main.post { speak("تعذر الاتصال بالذكاء الاصطناعي") }; return@Thread
                }
                val json = try {
                    JSONObject(reply.substring(reply.indexOf('{'), reply.lastIndexOf('}') + 1))
                } catch (e: Exception) { main.post { speak("لم أفهم رد الذكاء الاصطناعي") }; return@Thread }

                val acts = json.optJSONArray("actions") ?: JSONArray()
                for (i in 0 until acts.length()) {
                    val a = acts.getJSONObject(i)
                    log.append(a.toString()).append('\n')
                    exec(ctx, svc, a)
                    Thread.sleep(900)
                }
                lastSay = json.optString("say", lastSay)
                if (json.optBoolean("done", false)) break
            }
            if (lastSay.isNotBlank()) main.post { speak(lastSay) }
        }.start()
    }

    private fun exec(ctx: Context, svc: PhoneControlService, a: JSONObject) {
        when (a.optString("type")) {
            "click" -> svc.clickText(a.optString("text"))
            "type" -> svc.typeText(a.optString("text"))
            "scroll" -> svc.scroll(a.optString("dir") == "down")
            "swipe" -> svc.swipeSide(a.optString("dir") == "left")
            "back" -> svc.back()
            "home" -> svc.home()
            "recents" -> svc.recents()
            "notifications" -> svc.notifications()
            "open_app" -> Actions.openApp(ctx, a.optString("name"))
            "search" -> Actions.webSearch(ctx, a.optString("query"))
            else -> {}
        }
    }

    private fun ask(ctx: Context, prompt: String): String {
        val body = JSONObject()
            .put("model", Prefs.model(ctx))
            .put("max_tokens", 1000)
            .put("system", SYSTEM)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000; c.readTimeout = 60000
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", Prefs.apiKey(ctx))
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val text = (if (c.responseCode in 200..299) c.inputStream else c.errorStream)
            .bufferedReader().use { it.readText() }
        if (c.responseCode !in 200..299) throw RuntimeException(text)
        return JSONObject(text).getJSONArray("content").getJSONObject(0).getString("text")
    }
}
