package com.example.voicecontrol

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("vc", Context.MODE_PRIVATE)

    fun apiKey(c: Context) = sp(c).getString("apiKey", "") ?: ""
    fun wakeWord(c: Context) = sp(c).getString("wake", "يا هاتف") ?: "يا هاتف"
    fun requireWake(c: Context) = sp(c).getBoolean("requireWake", true)
    fun lang(c: Context) = sp(c).getString("lang", "ar-SA") ?: "ar-SA"
    fun model(c: Context) = sp(c).getString("model", "claude-sonnet-5-5") ?: "claude-sonnet-5-5"

    fun save(c: Context, apiKey: String, wake: String, requireWake: Boolean, lang: String) {
        sp(c).edit()
            .putString("apiKey", apiKey.trim())
            .putString("wake", wake.trim())
            .putBoolean("requireWake", requireWake)
            .putString("lang", lang)
            .apply()
    }
}
